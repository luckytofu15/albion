# Albion Profit Radar

A zero-dependency Node web app for scanning Albion Online markets for flipping, crafting and refining opportunities.

## Features
- Americas / Europe / Asia realm selector.
- Bridgewatch, Fort Sterling, Lymhurst, Martlock, Thetford, Caerleon, Brecilien and Black Market.
- Flip scanner: instant buy vs buy-order sourcing, sell-order vs instant exit, fee/tax/risk-buffer handling.
- Craft/refine scanner: recipe materials, global cheapest-material sourcing, return rate, focus preset, station fee, fixed recipe silver cost, journal value.
- Freshness rejection for stale quotes.
- Optional 7-day volume enrichment for top opportunities.
- Daily-picks ranking and CSV export.
- Server-side batching/caching to stay friendly to Albion Online Data Project request limits and URL-length limits.
- Full recipe database generator from `ao-data/ao-bin-dumps`.

## Run
1. Install Node.js 20+.
2. From this folder, run `npm start`.
3. Open `http://localhost:4173`.

The included demo recipe database lets the site work immediately for a small set of common items/resources.

## Build the full recipe database
Run:

`npm run sync-data`

This downloads current `ao-data/ao-bin-dumps` item metadata and writes `data/recipes.json`. Restart the server after it finishes. The scanner will then use the full generated recipe universe.

## Important assumptions
Default marketplace settings in the UI are editable. The app starts with Premium sales tax 4% and setup fee 2.5%, but you should keep these inputs aligned with current in-game values.

Station cost is modeled as `itemValue × 0.1125 × stationUsageFee%`, plus any fixed silver cost found in recipe metadata. Resource returns apply only to inputs marked returnable in the game data.

Market prices come from the community-run Albion Online Data Project and can be sparse or stale. The scanner rejects zero prices and includes quote-age filtering. Always verify large trades in-game.

## Deploy
This project has no npm dependencies. Any host that can run Node 20+ works. For always-on daily snapshots, deploy the server to a persistent host and add a cron job or scheduled function that calls the scan endpoints and stores results in a database.
