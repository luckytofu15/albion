const CITIES = ["Bridgewatch","Fort Sterling","Lymhurst","Martlock","Thetford","Caerleon","Brecilien","Black Market"];
const state = { mode:"flip", recipes:{}, rows:[], rawRows:[], scanning:false };

const $ = (id)=>document.getElementById(id);
const fmt = new Intl.NumberFormat('en-US',{maximumFractionDigits:0});
const money = n => Number.isFinite(n) ? (n<0?'-':'') + fmt.format(Math.abs(n)) : '—';
const pct = n => Number.isFinite(n) ? `${n.toFixed(1)}%` : '—';
const ageHours = iso => { if(!iso || iso.startsWith('0001')) return Infinity; return (Date.now()-new Date(iso).getTime())/36e5; };
const humanAge = h => !Number.isFinite(h)?'no data':h<1?`${Math.max(1,Math.round(h*60))}m`:h<48?`${Math.round(h)}h`:`${Math.round(h/24)}d`;
const parseIds = s => [...new Set(s.split(/[\s,;]+/).map(v=>v.trim()).filter(Boolean))];
const escapeHtml = s => String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));

function buildCities(){
  const el=$('cityChecks');
  CITIES.forEach((city,i)=>{
    const lab=document.createElement('label'); lab.className='check-chip';
    const checked = city==='Black Market' ? true : city!=='Brecilien';
    lab.innerHTML=`<input type="checkbox" data-city="${city}" ${checked?'checked':''}><span>${city}</span>`;
    el.appendChild(lab);
  });
}

function selectedCities(){
  let cities=[...document.querySelectorAll('[data-city]:checked')].map(x=>x.dataset.city);
  if(!$('includeBM').checked) cities=cities.filter(c=>c!=='Black Market');
  return cities;
}

function setMode(mode){
  const previous=state.mode; state.mode=mode;
  document.querySelectorAll('#modeTabs button').forEach(b=>b.classList.toggle('active',b.dataset.mode===mode));
  $('modeBadge').textContent=mode.toUpperCase();
  document.querySelectorAll('.mode-craft').forEach(el=>el.style.display=mode==='flip'?'none':'');
  if(mode!=='flip' && mode!==previous){ $('returnRate').value = $('useFocus').checked ? (mode==='refine'?53.9:47.9) : (mode==='refine'?36.7:24.8); updateLabels(); }
  filterUniverseHint();
}

function syncTax(){ $('salesTax').value=$('premium').checked ? 4 : 8; }
function syncFocus(){ $('useReturn').checked=true; $('returnRate').value=$('useFocus').checked ? (state.mode==='refine'?53.9:47.9) : (state.mode==='refine'?36.7:24.8); updateLabels(); }
function updateLabels(){
  $('minProfitLabel').textContent = `${Math.round(+$('minProfit').value/1000)}k`;
  $('minRoiLabel').textContent = `${$('minRoi').value}%`;
  $('riskLabel').textContent = `${$('riskBuffer').value}%`;
  $('rrrLabel').textContent = `${$('returnRate').value}%`;
  $('stationLabel').textContent = `${$('stationFee').value}%`;
}
function filterUniverseHint(){
  const all=Object.values(state.recipes);
  const count=state.mode==='flip' ? Object.keys(state.recipes).length : all.filter(r=>r.kind===state.mode).length;
  $('recipeCount').textContent=`${fmt.format(count)} ${state.mode==='flip'?'items':'recipes'} loaded`;
}

async function loadRecipes(){
  try{
    const r=await fetch('/api/recipes');
    if(!r.ok) throw new Error('recipe endpoint unavailable');
    const data=await r.json(); state.recipes=data.items||{};
    filterUniverseHint();
  }catch(e){
    try{ const r=await fetch('/data/recipes.demo.json'); const data=await r.json(); state.recipes=data.items||{}; filterUniverseHint(); }
    catch{ $('recipeCount').textContent='Recipe data unavailable'; }
  }
}

function universe(){
  const manual=parseIds($('itemIds').value);
  if(manual.length) return manual;
  if(state.mode==='flip'){
    const base = new Set(Object.keys(state.recipes));
    Object.values(state.recipes).forEach(r=>(r.materials||[]).forEach(m=>base.add(m.id)));
    return [...base].slice(0,700);
  }
  return Object.entries(state.recipes).filter(([,r])=>r.kind===state.mode).map(([id])=>id).slice(0,900);
}

async function apiPrices(items,cities){
  if(!items.length||!cities.length) return [];
  const q=new URLSearchParams({server:$('serverSelect').value,items:items.join(','),locations:cities.join(','),quality:$('quality').value});
  const r=await fetch(`/api/prices?${q}`); if(!r.ok) throw new Error(`Price API ${r.status}`); return r.json();
}

async function apiHistory(items,locations){
  if(!items.length||!locations.length) return [];
  const q=new URLSearchParams({server:$('serverSelect').value,items:items.join(','),locations:locations.join(','),quality:$('quality').value,days:'7'});
  const r=await fetch(`/api/history?${q}`); if(!r.ok) return []; return r.json();
}

function makePriceMap(prices){
  const m=new Map();
  for(const p of prices) m.set(`${p.item_id}|${p.city}`,p);
  return m;
}
function sourceQuote(q){
  if(!q) return null;
  const buyOrder=$('buyOrders').checked;
  const price=buyOrder?q.buy_price_max:q.sell_price_min;
  const date=buyOrder?q.buy_price_max_date:q.sell_price_min_date;
  return price>0?{price,date,age:ageHours(date)}:null;
}
function exitQuote(q,city){
  if(!q) return null;
  const order=$('sellOrders').checked && city!=='Black Market';
  const price=order?q.sell_price_min:q.buy_price_max;
  const date=order?q.sell_price_min_date:q.buy_price_max_date;
  return price>0?{price,date,age:ageHours(date),order}:null;
}
function feesForSale(sale,order){
  const tax=+$('salesTax').value/100;
  const setup=order?+$('setupFee').value/100:0;
  return sale*(tax+setup);
}
function riskCost(base){ return base*(+$('riskBuffer').value/100); }

function flipRows(ids,prices,cities){
  const map=makePriceMap(prices), out=[];
  const maxAge=+$('maxAge').value;
  for(const id of ids){
    const name=state.recipes[id]?.name || id;
    for(const from of cities.filter(c=>c!=='Black Market')){
      const src=sourceQuote(map.get(`${id}|${from}`)); if(!src||src.age>maxAge) continue;
      for(const to of cities){
        if(to===from) continue;
        const dst=exitQuote(map.get(`${id}|${to}`),to); if(!dst||dst.age>maxAge) continue;
        const acquisition=src.price;
        const buySetup=$('buyOrders').checked ? acquisition*(+$('setupFee').value/100) : 0;
        const sellFees=feesForSale(dst.price,dst.order);
        const risk=riskCost(acquisition);
        const profit=dst.price-acquisition-buySetup-sellFees-risk;
        const roi=acquisition>0?profit/(acquisition+buySetup+risk)*100:0;
        out.push({id,name,kind:'flip',from,to,buy:acquisition,sell:dst.price,fees:buySetup+sellFees+risk,profit,roi,age:Math.max(src.age,dst.age),volume:null,score:0,detail:`${$('buyOrders').checked?'Buy order':'Instant buy'} → ${dst.order?'Sell order':'Instant sell'}`});
      }
    }
  }
  return out;
}

function cheapestMaterial(material,map,cities,maxAge){
  let best=material.vendorPrice>0?{price:material.vendorPrice,date:new Date().toISOString(),age:0,city:'Vendor'}:null;
  for(const city of cities.filter(c=>c!=='Black Market')){
    const q=sourceQuote(map.get(`${material.id}|${city}`));
    if(!q||q.age>maxAge) continue;
    if(!best||q.price<best.price) best={...q,city};
  }
  return best;
}

function craftRows(ids,prices,cities){
  const map=makePriceMap(prices), out=[], maxAge=+$('maxAge').value;
  const rrr=$('useReturn').checked ? +$('returnRate').value/100 : 0;
  const stationRate=+$('stationFee').value/100;
  const journal=+$('journalValue').value;
  for(const id of ids){
    const recipe=state.recipes[id]; if(!recipe||!(recipe.materials||[]).length) continue;
    const craftCity=recipe.city && cities.includes(recipe.city) ? recipe.city : cities.find(c=>c!=='Black Market');
    if(!craftCity) continue;
    let matCost=0, maxMatAge=0, sourceNames=[], valid=true;
    for(const mat of recipe.materials){
      let src;
      if($('globalSource').checked) src=cheapestMaterial(mat,map,cities,maxAge);
      else { const q=sourceQuote(map.get(`${mat.id}|${craftCity}`)); src=q?{...q,city:craftCity}:null; if(mat.vendorPrice>0 && (!src || mat.vendorPrice<src.price)) src={price:mat.vendorPrice,date:new Date().toISOString(),age:0,city:'Vendor'}; }
      if(!src||src.age>maxAge){ valid=false; break; }
      const effectiveCount = mat.count * (mat.returnable===false ? 1 : (1-rrr));
      const base=src.price*effectiveCount;
      matCost+=base + ($('buyOrders').checked ? base*(+$('setupFee').value/100) : 0);
      maxMatAge=Math.max(maxMatAge,src.age); sourceNames.push(src.city);
    }
    if(!valid) continue;
    const amount=recipe.amountCrafted||1;
    const station=((recipe.itemValue||0)*0.1125*stationRate)+(recipe.silverCost||0);
    const totalCost=(matCost+station)/amount;
    for(const to of cities){
      const dst=exitQuote(map.get(`${id}|${to}`),to); if(!dst||dst.age>maxAge) continue;
      const sellPerUnit=dst.price;
      const sellFees=feesForSale(sellPerUnit,dst.order);
      const risk=riskCost(totalCost);
      const profit=sellPerUnit-sellFees-totalCost-risk+journal;
      const roi=totalCost>0?profit/(totalCost+risk)*100:0;
      const uniqueSources=[...new Set(sourceNames)];
      out.push({id,name:recipe.name||id,kind:recipe.kind||state.mode,from:craftCity,to,buy:totalCost,sell:sellPerUnit,fees:sellFees+station+risk,profit,roi,age:Math.max(maxMatAge,dst.age),volume:null,score:0,detail:`${uniqueSources.length>1?'Global mats':uniqueSources[0]||craftCity} → ${craftCity} craft → ${to}`});
    }
  }
  return out;
}

function prefilter(rows){
  const minP=+$('minProfit').value, minR=+$('minRoi').value;
  return rows.filter(r=>r.profit>=minP&&r.roi>=minR).sort((a,b)=>b.profit-a.profit).slice(0,250);
}

async function addLiquidity(rows){
  if(!$('liquidity').checked||!rows.length) return rows;
  const top=rows.slice(0,18);
  const ids=[...new Set(top.map(r=>r.id))];
  const locs=[...new Set(top.map(r=>r.to))];
  try{
    const h=await apiHistory(ids,locs);
    const vm=new Map();
    for(const series of h){
      const key=`${series.item_id}|${series.location}`;
      const pts=series.data||[];
      const vol=pts.reduce((s,p)=>s+(+p.item_count||0),0)/Math.max(1,Math.min(7,pts.length));
      vm.set(key,vol);
    }
    rows.forEach(r=>r.volume=vm.get(`${r.id}|${r.to}`)??null);
  }catch{}
  return rows;
}

function scoreRows(rows){
  const minVol=+$('minVolume').value;
  rows.forEach(r=>{
    const freshness=Math.max(0,1-Math.min(r.age,72)/72);
    const volume=r.volume==null?1:Math.log10(1+r.volume);
    r.score=Math.max(0,Math.round((Math.min(Math.max(r.roi,0),100)*0.48 + Math.min(Math.max(r.profit/2500,0),100)*0.32 + freshness*20) * Math.min(1.35,.8+volume*.18)));
  });
  return rows.filter(r=>r.volume==null||r.volume>=minVol).sort((a,b)=>b.score-a.score||b.profit-a.profit);
}

function render(){
  const q=$('searchResults').value.trim().toLowerCase();
  const rows=state.rows.filter(r=>!q||`${r.name} ${r.id} ${r.from} ${r.to}`.toLowerCase().includes(q));
  $('resultsBody').innerHTML=rows.map(r=>`<tr>
    <td><span class="score-pill">${r.score}</span></td>
    <td><strong>${escapeHtml(r.name)}</strong><br><span class="tag">${escapeHtml(r.id)}</span></td>
    <td><strong>${escapeHtml(r.from)}</strong> → <strong>${escapeHtml(r.to)}</strong><br><span class="tag">${escapeHtml(r.detail)}</span></td>
    <td>${money(r.buy)}</td><td>${money(r.sell)}</td><td>${money(r.fees)}</td>
    <td class="${r.profit>=0?'money-pos':'money-neg'}">${money(r.profit)}</td><td>${pct(r.roi)}</td>
    <td>${r.volume==null?'—':fmt.format(Math.round(r.volume))}/d</td><td class="${r.age<=12?'fresh':'stale'}">${humanAge(r.age)}</td>
  </tr>`).join('');

  const top=state.rows.slice(0,3);
  $('dailyCards').innerHTML=top.length?top.map((r,i)=>`<article class="daily-card"><span class="rank">#${i+1} · SCORE ${r.score}</span><h4>${escapeHtml(r.name)}</h4><div class="route">${escapeHtml(r.from)} → ${escapeHtml(r.to)}</div><div class="daily-metrics"><div><strong>${money(r.profit)}</strong><span>NET SILVER</span></div><div><strong>${pct(r.roi)}</strong><span>ROI</span></div><div><strong>${r.volume==null?'—':fmt.format(Math.round(r.volume))}</strong><span>VOL/DAY</span></div></div></article>`).join(''):'<div class="empty-state">No opportunities pass the current profit/ROI filters.</div>';

  if(state.rows.length){
    const bestP=[...state.rows].sort((a,b)=>b.profit-a.profit)[0], bestR=[...state.rows].sort((a,b)=>b.roi-a.roi)[0];
    $('bestProfit').textContent=money(bestP.profit); $('bestProfitSub').textContent=bestP.name;
    $('bestRoi').textContent=pct(bestR.roi); $('bestRoiSub').textContent=bestR.name;
    $('freshCount').textContent=fmt.format(state.rows.filter(r=>r.age<=12).length); $('freshSub').textContent=`${state.rows.length} passing filters`;
  } else { ['bestProfit','bestRoi','freshCount'].forEach(id=>$(id).textContent='—'); }
}

async function scan(){
  if(state.scanning) return; state.scanning=true; document.body.classList.add('loading');
  $('feedStatus').textContent='Scanning markets'; $('scanMessage').className='scan-message'; $('scanMessage').textContent='Fetching quotes and calculating net opportunity…';
  try{
    const ids=universe(), cities=selectedCities(); if(!ids.length) throw new Error('No item IDs or recipes are available.'); if(cities.length<1) throw new Error('Select at least one market.');
    let fetchIds=[...ids];
    if(state.mode!=='flip') ids.forEach(id=>(state.recipes[id]?.materials||[]).forEach(m=>fetchIds.push(m.id)));
    fetchIds=[...new Set(fetchIds)];
    const prices=await apiPrices(fetchIds,cities);
    const quotes=prices.filter(p=>p.sell_price_min>0||p.buy_price_max>0).length;
    $('coverage').textContent=`${Math.round(100*quotes/Math.max(1,fetchIds.length*cities.length))}%`;
    $('coverageSub').textContent=`${fmt.format(quotes)} usable quotes`;
    let rows=state.mode==='flip'?flipRows(ids,prices,cities):craftRows(ids,prices,cities);
    rows=prefilter(rows); rows=await addLiquidity(rows); rows=scoreRows(rows);
    state.rawRows=rows; state.rows=rows.slice(0,150); render();
    $('scanMessage').textContent=`Scanned ${fmt.format(fetchIds.length)} item IDs across ${cities.length} markets. Showing ${state.rows.length} ranked opportunities.`;
    const now=new Date(); $('lastScan').textContent=`Updated ${now.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}`; $('feedStatus').textContent='Live scan complete';
    localStorage.setItem('albionProfitRadarLastScan',JSON.stringify({at:Date.now(),mode:state.mode,top:state.rows.slice(0,10)}));
  }catch(e){ $('scanMessage').textContent=e.message||String(e); $('scanMessage').className='scan-message error'; $('feedStatus').textContent='Scan failed'; }
  finally{state.scanning=false;document.body.classList.remove('loading');}
}

function exportCsv(){
  if(!state.rows.length) return;
  const cols=['score','id','name','kind','from','to','buy','sell','fees','profit','roi','volume','age','detail'];
  const csv=[cols.join(','),...state.rows.map(r=>cols.map(c=>`"${String(r[c]??'').replaceAll('"','""')}"`).join(','))].join('\n');
  const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'})); a.download=`albion-profit-radar-${state.mode}-${new Date().toISOString().slice(0,10)}.csv`; a.click(); URL.revokeObjectURL(a.href);
}

function reset(){
  $('premium').checked=true;$('buyOrders').checked=false;$('sellOrders').checked=true;$('includeBM').checked=true;$('globalSource').checked=true;$('useReturn').checked=true;$('useFocus').checked=false;$('liquidity').checked=true;$('autoScan').checked=true;
  $('minProfit').value=5000;$('minRoi').value=5;$('riskBuffer').value=2;$('returnRate').value=24.8;$('stationFee').value=10;$('setupFee').value=2.5;$('salesTax').value=4;$('journalValue').value=0;$('minVolume').value=0;$('maxAge').value=12;$('quality').value=1;$('itemIds').value=''; updateLabels();
}

function restoreCached(){ try{const c=JSON.parse(localStorage.getItem('albionProfitRadarLastScan')||'null');if(c?.top?.length){state.rows=c.top;render();$('lastScan').textContent=`Cached ${humanAge((Date.now()-c.at)/36e5)} ago`;}}catch{} }

buildCities(); updateLabels(); setMode('flip'); loadRecipes().then(()=>{restoreCached(); if($('autoScan').checked)setTimeout(scan,500)});
setInterval(()=>{if($('autoScan').checked&&!document.hidden)scan()},30*60*1000);
$('modeTabs').addEventListener('click',e=>{const b=e.target.closest('button[data-mode]');if(b)setMode(b.dataset.mode)});
$('premium').addEventListener('change',syncTax); $('useFocus').addEventListener('change',syncFocus);
['minProfit','minRoi','riskBuffer','returnRate','stationFee'].forEach(id=>$(id).addEventListener('input',updateLabels));
$('refreshBtn').addEventListener('click',scan); $('resetBtn').addEventListener('click',reset); $('searchResults').addEventListener('input',render); $('exportBtn').addEventListener('click',exportCsv);
$('allCitiesBtn').addEventListener('click',()=>document.querySelectorAll('[data-city]').forEach(x=>x.checked=true));
