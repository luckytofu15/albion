# Albion Profit Radar — iPhone Home Screen App v2

A mobile-first Progressive Web App (PWA) for scanning Albion Online craft, refine and market-flip opportunities.

## What's improved in v2

- iPhone-first interface with sticky strategy switcher and bottom navigation
- Large touch targets and one-handed **Scan** / **Filters** controls
- Mobile result cards instead of a tiny desktop table
- Dedicated filter bottom sheet
- Clearly separated live and demo modes
- Demo mode works without live market data so the interface can be tested immediately
- Live mode calls the Albion Online Data Project directly from the browser and falls back to the included Node proxy when available
- Relative PWA paths, so the project can be hosted in a subfolder such as GitHub Pages
- Home Screen icon, standalone display, safe-area layout, and offline app-shell cache

## Fastest local test

### Option A — interface-only
Open `index.html` in a browser and press **Try demo**. Local-file restrictions vary by browser, so Home Screen installation is not expected from this mode.

### Option B — full local web server
Requires Node.js 20+:

```bash
npm start
```

Open `http://localhost:4173` on the computer. On an iPhone connected to the same Wi-Fi, open the computer's LAN address, e.g. `http://192.168.1.50:4173`.

## Install on iPhone Home Screen

For the proper standalone PWA experience, host this folder over HTTPS (GitHub Pages, Cloudflare Pages, Netlify, Vercel static hosting, etc.). Then:

1. Open the HTTPS URL in **Safari**.
2. Tap **Share**.
3. Tap **Add to Home Screen**.
4. Tap **Add**.
5. Launch **Albion Radar** from its Home Screen icon.

## Live-data notes

The frontend batches item IDs to keep market requests below URL-size limits. The included `server.mjs` proxy remains available as a fallback, but v2 no longer requires it for normal static-host use when the public market API is reachable from the browser.

`data/recipes.demo.json` is intentionally small. Run `npm run sync-data` on an internet-connected computer before deployment to generate the larger recipe dataset if desired.

Community market data can be delayed or incomplete. Always verify large trades in game before committing silver.
